<?php
class Auto_assign_leads_model extends App_Model
{
}