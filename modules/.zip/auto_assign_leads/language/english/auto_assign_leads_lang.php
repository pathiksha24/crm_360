<?php

$lang['auto_assign_leads'] = 'Auto Assign Leads';
$lang['max_leads_to_distribute'] = 'Max Leads To Distribute';
$lang['max_leads_for_each_staff'] = 'Max Leads For each Staff';
$lang['total_assigned_leads'] = 'Total Assigned Leads';